define({
	/* This is here because it needs to be so that the ad loads properly and we don't get a 404 error. */
});